Submitted by: Sang Pham (directory id: spham254)

App Description: A book review application that allows users to search for books using the Google Books API, add reviews, and view recent reviews.

YouTube Video Link: [https://www.youtube.com/watch?v=example123](https://www.youtube.com/watch?v=example123)

APIs: 
- Google Books API: [https://developers.google.com/books](https://developers.google.com/books)

Contact Email: ajohn123@terpmail.umd.edu

Deployed App Link: [https://book-review-app.onrender.com](https://book-review-app.onrender.com)